
from setuptools import setup

setup(
    name="package",
    version="0.1",
    packages=['package']
) 
