
def hello_world():
    return 'hello world!'
