# test_package
It's for testing download and extract zip file used in cloud instance
